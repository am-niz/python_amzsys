f = open("foo.txt", "r")
# r = f.read()
# print(r)

r = f.readlines()
print(r)
